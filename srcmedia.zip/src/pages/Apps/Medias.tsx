import { DataTable } from 'mantine-datatable';
import { Fragment, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { setPageTitle } from '../../store/themeConfigSlice';
import IconBell from '../../components/Icon/IconBell';
import axios from 'axios';
import { MY_CAT_MEDIA_URL, MY_DASHBOARD_URL, MY_MEDIA_URL, MY_YEAR_MEDIA_URL } from './query';
import { Dialog, Transition } from '@headlessui/react';
import IconX from '../../components/Icon/IconX';
import IconEye from '../../components/Icon/IconEye';
import IconDownload from '../../components/Icon/IconDownload';
import ReactPlayer from 'react-player';
import img from '/public/crown-logo.png';
import html2canvas from 'html2canvas';
import 'tippy.js/dist/tippy.css';
import React from 'react';
import ReactAudioPlayer from 'react-audio-player';

const tableData = [
    {
        id: 1,

        type: 'Audio',

        action: '',
    },
    {
        id: 2,

        type: 'Video',

        action: '',
    },
    {
        id: 3,

        type: 'Image',

        action: '',
    },
];
const Skin = () => {
    const [first, setfirst] = useState(true);
    const [second, setsecond] = useState(false);
    const [third, setthird] = useState(false);
    const [fourth, setfourth] = useState(false);
    const [fifth, setfifth] = useState(false);
    const [search, setSearch] = useState('');
    const [modal10, setModal10] = useState(false);
    const [categ1, setcateg1] = useState(true);
    const [categ2, setcateg2] = useState(false);
    const [categ3, setcateg3] = useState(false);
    const [categ4, setcateg4] = useState(false);

    const [data, setData] = useState([]);
    const [page, setPage] = useState(1);

    const imgRef = React.createRef<HTMLImageElement>();

    // useEffect(() => {
    //     const fetchData = async () => {
    //         try {
    //             const headers = {
    //                 'Content-Type': 'application/json',
    //                 Authorization: localStorage.token,
    //             };
    //             const postData = {
    //                 studentID: localStorage.studentID,
    //                 schoolID: localStorage.schoolID,
    //                 schoolyearID: localStorage.schoolyearID,
    //                 classesID: localStorage.classesID,
    //                 sectionID: localStorage.sectionID,
    //             };
    //             const response = await axios.post(MY_MEDIA_URL, postData, {
    //                 headers: headers,
    //             });

    //             console.log('media', response);
    //             // if (response.data.error) {
    //             //     // setUsererror(response.data.message);
    //             // } else {
    //             //     const profiledtls = response.data.data;
    //             //     console.log('profiledtls:', profiledtls);

    //             //     // setProfile(profiledtls);
    //             // }
    //         } catch (error) {
    //             console.error('Error fetching data:', error);
    //         }
    //     };

    //     // Call the fetchData function when the component mounts
    //     fetchData();
    // }, []);
    // useEffect(() => {
    //     const fetchData = async () => {
    //         try {
    //             const headers = {
    //                 'Content-Type': 'application/json',
    //                 Authorization: localStorage.token,
    //             };
    //             const postData = {
    //                 studentID: localStorage.studentID,
    //                 schoolID: localStorage.schoolID,
    //                 schoolyearID: 112,
    //                 classesID: localStorage.classesID,
    //                 sectionID: localStorage.sectionID,
    //             };
    //             const response = await axios.post(MY_YEAR_MEDIA_URL, postData, {
    //                 headers: headers,
    //             });

    //             console.log('year_media', response);
    //             // if (response.data.error) {
    //             //     // setUsererror(response.data.message);
    //             // } else {
    //             //     const profiledtls = response.data.data;
    //             //     console.log('profiledtls:', profiledtls);

    //             //     // setProfile(profiledtls);
    //             // }
    //         } catch (error) {
    //             console.error('Error fetching data:', error);
    //         }
    //     };

    //     // Call the fetchData function when the component mounts
    //     fetchData();
    // }, []);
    // useEffect(() => {
    //     const fetchData = async () => {
    //         try {
    //             const headers = {
    //                 'Content-Type': 'application/json',
    //                 Authorization: localStorage.token,
    //             };
    //             const postData = {
    //                 studentID: localStorage.studentID,
    //                 schoolID: localStorage.schoolID,
    //                 schoolyearID: 161,
    //                 mcategoryID: 318,
    //                 classesID: localStorage.classesID,
    //                 sectionID: localStorage.sectionID,
    //             };
    //             const response = await axios.post(MY_CAT_MEDIA_URL, postData, {
    //                 headers: headers,
    //             });

    //             console.log('cat_media', response);
    //             // if (response.data.error) {
    //             //     // setUsererror(response.data.message);
    //             // } else {
    //             //     const profiledtls = response.data.data;
    //             //     console.log('profiledtls:', profiledtls);

    //             //     // setProfile(profiledtls);
    //             // }
    //         } catch (error) {
    //             console.error('Error fetching data:', error);
    //         }
    //     };

    //     // Call the fetchData function when the component mounts
    //     fetchData();
    // }, []);

    // useEffect(() => {
    //     setInitialRecords(() => {
    //         return rowData.filter((item) => {
    //             return (
    //                 item.id.toString().includes(search.toLowerCase()) ||
    //                 //item.action.toLowerCase().includes(search.toLowerCase()) ||
    //                 // item.status.toLowerCase().includes(search.toLowerCase()) ||
    //                 item.type.toLowerCase().includes(search.toLowerCase()) ||
    //                 item.started.toLowerCase().includes(search.toLowerCase())
    //             );
    //         });
    //     });
    //     // eslint-disable-next-line react-hooks/exhaustive-deps
    // }, [search]);

    //Skin: Hover
    // const [page1, setPage1] = useState(1);
    // const [pageSize1, setPageSize1] = useState(PAGE_SIZES[0]);
    // const [initialRecords1, setInitialRecords1] = useState(rowData);
    // const [recordsData1, setRecordsData1] = useState(initialRecords1);

    //Skin: Bordered

    const fetchData = async () => {
        try {
            const headers = {
                'Content-Type': 'application/json',
                Authorization: localStorage.token,
            };
            const postData = {
                studentID: localStorage.studentID,
                schoolID: localStorage.schoolID,
                schoolyearID: 161,
                mcategoryID: 318,
                classesID: localStorage.classesID,
                sectionID: localStorage.sectionID,
            };
            const response = await axios.post(MY_CAT_MEDIA_URL + `?page=${page}`, postData, {
                headers: headers,
            });

            console.log('cat_media123', response);
            // if (response.data.error) {
            //     // setUsererror(response.data.message);
            // } else {
            //     const profiledtls = response.data.data;
            //     console.log('profiledtls:', profiledtls);

            //     // setProfile(profiledtls);
            // }
        } catch (error) {
            console.error('Error fetching data:', error);
        }
    };

    useEffect(() => {
        fetchData();
    }, [page]);

    const loadMore = () => {
        setPage((prevPage) => prevPage + 1);
    };

    const firstclick = () => {
        setfirst(true);
        setsecond(false);
        setthird(false);
        setfourth(false);
        setfifth(false);
        setcateg1(true);
        setcateg2(false);
        setcateg3(false);
        setcateg4(false);
    };
    const secondclick = () => {
        setfirst(false);
        setsecond(true);
        setthird(false);
        setfourth(false);
        setfifth(false);
        setcateg1(true);
        setcateg2(false);
        setcateg3(false);
        setcateg4(false);
    };
    const thirdclick = () => {
        setfirst(false);
        setsecond(false);
        setthird(true);
        setfourth(false);
        setfifth(false);
        setcateg1(true);
        setcateg2(false);
        setcateg3(false);
        setcateg4(false);
    };
    const fourthtclick = () => {
        setfirst(false);
        setsecond(false);
        setthird(false);
        setfourth(true);
        setfifth(false);
        setcateg1(true);
        setcateg2(false);
        setcateg3(false);
        setcateg4(false);
    };
    const fifthclick = () => {
        setfirst(false);
        setsecond(false);
        setthird(false);
        setfourth(false);
        setfifth(true);
        setcateg1(true);
        setcateg2(false);
        setcateg3(false);
        setcateg4(false);
    };

    const handlecatg1 = () => {
        setcateg1(true);
        setcateg2(false);
        setcateg3(false);
        setcateg4(false);
    };
    const handlecatg2 = () => {
        setcateg1(false);
        setcateg2(true);
        setcateg3(false);
        setcateg4(false);
    };
    const handlecatg3 = () => {
        setcateg1(false);
        setcateg2(false);
        setcateg3(true);
        setcateg4(false);
    };
    const handlecatg4 = () => {
        setcateg1(false);
        setcateg2(false);
        setcateg3(false);
        setcateg4(true);
    };

    const downloadPdf = () => {
        const pdfUrl = '/src/Application.pdf';
        // Update the path based on your actual PDF file
        const link = document.createElement('a');
        link.href = pdfUrl;
        link.download = 'Application.pdf';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
    };
    const handleDownload = () => {
        const imageElement = imgRef.current;

        if (imageElement) {
            // Added this check
            html2canvas(imageElement).then((canvas) => {
                const dataURL = canvas.toDataURL('image/png');
                const a = document.createElement('a');
                a.href = dataURL;
                a.download = 'downloaded-image.png';
                document.body.appendChild(a);
                a.click();
                document.body.removeChild(a);
            });
        }
    };

    return (
        <div className="space-y-6">
            {/* Skin: Striped  */}
            <div>
                <h4 className="font-semibold text-lg">Facilities</h4>
            </div>

            <button onClick={loadMore}>Load More</button>
            <div className="panel">
                <div className="flex items-center justify-between pb-5 mb-4 border-b-2 ">
                    <h5 className="font-semibold text-lg dark:text-white-light">Media</h5>
                    {/* <div>
                        <select name="Select Category" defaultValue="Select Category" className="w-18 h-10 p-2 mr-2 border rounded-md ">
                            <option value="Select Category">Select Category</option>
                            <option value="Audio">Audio</option>
                            <option value="Video">Video</option>
                            <option value="Image">Image</option>
                        </select>
                        <input type="text" className="form-input w-auto" placeholder="Search..." value={search} onChange={(e) => setSearch(e.target.value)} />
                        <button className="text-white bg-blue-500 m-2 p-2 rounded-md">Go</button>
                    </div> */}
                </div>
                <div className="flex justify-start space-x-4 items-center">
                    <button
                        className={`p-1 border ${first ? 'bg-blue-500 text-white' : 'border-blue-500 bg-white  text-blue-500 hover:bg-blue-500 hover:text-white'} rounded-md  text-sm  `}
                        onClick={firstclick}
                    >
                        2024 - 2025
                    </button>
                    <button
                        className={`p-1 border ${second ? 'bg-blue-500 text-white' : 'border-blue-500 bg-white  text-blue-500 hover:bg-blue-500 hover:text-white'} rounded-md  text-sm  `}
                        onClick={secondclick}
                    >
                        2024 - 2025
                    </button>
                    <button
                        className={`p-1 border ${third ? 'bg-blue-500 text-white' : 'border-blue-500 bg-white  text-blue-500 hover:bg-blue-500 hover:text-white'} rounded-md  text-sm  `}
                        onClick={thirdclick}
                    >
                        2024 - 2025
                    </button>
                    <button
                        className={`p-1 border ${fourth ? 'bg-blue-500 text-white' : 'border-blue-500 bg-white  text-blue-500 hover:bg-blue-500 hover:text-white'} rounded-md  text-sm  `}
                        onClick={fourthtclick}
                    >
                        2024 - 2025
                    </button>
                    <button
                        className={`p-1 border ${fifth ? 'bg-blue-500 text-white' : 'border-blue-500 bg-white  text-blue-500 hover:bg-blue-500 hover:text-white'} rounded-md  text-sm  `}
                        onClick={fifthclick}
                    >
                        2024 - 2025
                    </button>
                </div>
                <div className="mt-4">
                    {first && (
                        <>
                            <div className="  ">
                                <div className="flex justify-start space-x-1.5 items-center">
                                    <button
                                        className={`${
                                            categ1 && first
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                        onClick={handlecatg1}
                                    >
                                        General
                                    </button>
                                    <button
                                        className={`${
                                            categ2 && first
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                        onClick={handlecatg2}
                                    >
                                        Teacher
                                    </button>
                                    <button
                                        className={`${
                                            categ3 && first
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                        onClick={handlecatg3}
                                    >
                                        Category1
                                    </button>
                                    <button
                                        className={`${
                                            categ4 && first
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                        onClick={handlecatg4}
                                    >
                                        Category2
                                    </button>
                                </div>
                            </div>
                        </>
                    )}
                    {second && (
                        <div className="  ">
                            <div className="flex justify-start space-x-1.5 items-center">
                                <button
                                    className={`${
                                        categ1 && second ? 'p-1 border border-gray-500 bg-gray-500 text-white' : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                    }  rounded-md text-sm`}
                                    onClick={handlecatg1}
                                >
                                    General
                                </button>
                                <button
                                    className={`${
                                        categ2 && second ? 'p-1 border border-gray-500 bg-gray-500 text-white' : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                    }  rounded-md text-sm`}
                                    onClick={handlecatg2}
                                >
                                    Teacher
                                </button>
                                <button
                                    className={`${
                                        categ3 && second ? 'p-1 border border-gray-500 bg-gray-500 text-white' : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                    }  rounded-md text-sm`}
                                    onClick={handlecatg3}
                                >
                                    Category1
                                </button>
                                <button
                                    className={`${
                                        categ4 && second ? 'p-1 border border-gray-500 bg-gray-500 text-white' : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                    }  rounded-md text-sm`}
                                    onClick={handlecatg4}
                                >
                                    Category2
                                </button>
                            </div>
                        </div>
                    )}
                    {third && (
                        <>
                            <div className="  ">
                                <div className="flex justify-start space-x-1.5 items-center">
                                    <button
                                        className={`${
                                            categ1 && third
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                    >
                                        General
                                    </button>
                                    <button
                                        className={`${
                                            categ2 && third
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                    >
                                        Teacher
                                    </button>
                                    <button
                                        className={`${
                                            categ3 && third
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                    >
                                        Category1
                                    </button>
                                    <button
                                        className={`${
                                            categ4 && third
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                    >
                                        Category2
                                    </button>
                                </div>
                            </div>
                        </>
                    )}
                    {fourth && (
                        <>
                            <div className="  ">
                                <div className="flex justify-start space-x-1.5 items-center">
                                    <button
                                        className={`${
                                            categ1 && fourth
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                    >
                                        General
                                    </button>
                                    <button
                                        className={`${
                                            categ2 && fourth
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                    >
                                        Teacher
                                    </button>
                                    <button
                                        className={`${
                                            categ3 && fourth
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                    >
                                        Category1
                                    </button>
                                    <button
                                        className={`${
                                            categ4 && fourth
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                    >
                                        Category2
                                    </button>
                                </div>
                            </div>
                        </>
                    )}
                    {fifth && (
                        <>
                            <div className="  ">
                                <div className="flex justify-start space-x-1.5 items-center">
                                    <button
                                        className={`${
                                            categ1 && fifth
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                        onClick={handlecatg1}
                                    >
                                        General
                                    </button>
                                    <button
                                        className={`${
                                            categ2 && fifth
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                        onClick={handlecatg2}
                                    >
                                        Teacher
                                    </button>
                                    <button
                                        className={`${
                                            categ3 && fifth
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                        onClick={handlecatg3}
                                    >
                                        Category1
                                    </button>
                                    <button
                                        className={`${
                                            categ4 && fifth
                                                ? 'p-1 border border-gray-500 bg-gray-500 text-white'
                                                : 'p-1 hover:bg-gray-500 border border-gray-500 hover:text-white bg-white text-gray-500'
                                        }  rounded-md text-sm`}
                                        onClick={handlecatg4}
                                    >
                                        Category2
                                    </button>
                                </div>
                            </div>
                        </>
                    )}
                </div>
                <div>
                    {categ1 && first && (
                        <>
                            <div className="mt-4">
                                <div className="panel">
                                    <div className="table-responsive mb-5">
                                        <table className="table-hover">
                                            <thead>
                                                <tr>
                                                    <th>SL.NO</th>
                                                    <th>FILE TYPE</th>

                                                    <th className="text-center">ACTION</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {tableData.map((data) => {
                                                    return (
                                                        <tr key={data.id}>
                                                            <td>{data.id}</td>
                                                            <td>
                                                                <div className="whitespace-nowrap">{data.type}</div>
                                                            </td>

                                                            <td>
                                                                <div>
                                                                    <button onClick={() => setModal10(true)} type="button" className="border border-blue-400 rounded-md">
                                                                        <IconEye />
                                                                    </button>
                                                                    <Transition appear show={modal10} as={Fragment}>
                                                                        <Dialog as="div" open={modal10} onClose={() => setModal10(false)}>
                                                                            <Transition.Child
                                                                                as={Fragment}
                                                                                enter="ease-out duration-100"
                                                                                enterFrom="opacity-0"
                                                                                enterTo="opacity-100"
                                                                                leave="ease-in duration-100"
                                                                                leaveFrom="opacity-100"
                                                                                leaveTo="opacity-0"
                                                                            >
                                                                                <div className="fixed inset-0" />
                                                                            </Transition.Child>
                                                                            <div id="slideIn_down_modal" className="fixed inset-0 z-[999] overflow-y-auto bg-black/20">
                                                                                <div className="flex min-h-screen items-start justify-center px-4">
                                                                                    <Dialog.Panel className="panel animate__animated animate__slideInDown my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                                                                        <div className="flex items-center justify-between bg-white px-5 py-3 dark:bg-white border-b">
                                                                                            <h5 className="text-lg font-bold">Book School Hotel</h5>
                                                                                            <button onClick={() => setModal10(false)} type="button" className="text-white-dark hover:text-dark">
                                                                                                <IconX />
                                                                                            </button>
                                                                                        </div>
                                                                                        {/* <iframe
                                                                        width="560"
                                                                        height="315"
                                                                        // src="https://www.youtube.com/embed/N2d7puNyPqw"
                                                                        src=".././public/assets/crown-logo.png"
                                                                        title="Video Title"
                                                                        //  frameBorder="0"

                                                                        allowFullScreen
                                                                        className="p-6 w-full "
                                                                    ></iframe> */}
                                                                                        <ReactPlayer
                                                                                            url="https://youtu.be/N2d7puNyPqw?si=fKY2WghPTEFRzlpR"
                                                                                            controls
                                                                                            width="700"
                                                                                            height="800"
                                                                                            className="p-4 w-full h-full"
                                                                                        />

                                                                                        {/* <img ref={imgRef} src={img} alt="" width="400px" height="300px" />
                                                                            <button onClick={handleDownload}>Download Image</button>
                                                                            <button onClick={downloadPdf}>Download PDF</button> */}

                                                                                        {/* <div className="p-5 ">
                                                                                <div className="font-bold flex items-center justify-center">School Hostel</div>
                                                                                <div className="font-bold flex items-center justify-center">Combine Hostel</div>
                                                                                <div className="font-bold flex items-center justify-center">Balaji Hostel</div>
                                                                            </div>
                                                                            <div className="mb-5 mr-0 ml-6 flex items-center ">
                                                                                <div className="max-w-[19rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-white-light dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
                                                                                    <div className="py-7 px-6">
                                                                                        <h5 className="text-[#3b3f5c] text-xl font-semibold mb-4 dark:text-white-light border-b">Simple</h5>
                                                                                        <p className="text-white-dark">No Of Rooms:30</p>
                                                                                        <p className="text-white-dark">Max. Members per Rooms:5</p>
                                                                                        <p className="text-white-dark">Members filled:38</p>
                                                                                    </div>
                                                                                </div>
                                                                            </div> */}
                                                                                    </Dialog.Panel>
                                                                                </div>
                                                                            </div>
                                                                        </Dialog>
                                                                    </Transition>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}

                    {first && categ2 && (
                        <>
                            <div className="mt-4">
                                <div className="panel">
                                    <div className="table-responsive mb-5">
                                        <table className="table-hover">
                                            <thead>
                                                <tr>
                                                    <th>SL.NO</th>
                                                    <th>FILE TYPE</th>

                                                    <th className="text-center">ACTION</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {tableData.map((data) => {
                                                    return (
                                                        <tr key={data.id}>
                                                            <td>{data.id}</td>
                                                            <td>
                                                                <div className="whitespace-nowrap">{data.type}</div>
                                                            </td>

                                                            <td>
                                                                <div>
                                                                    <button onClick={() => setModal10(true)} type="button" className="border border-blue-400 rounded-md">
                                                                        <IconEye />
                                                                    </button>
                                                                    <Transition appear show={modal10} as={Fragment}>
                                                                        <Dialog as="div" open={modal10} onClose={() => setModal10(false)}>
                                                                            <Transition.Child
                                                                                as={Fragment}
                                                                                enter="ease-out duration-100"
                                                                                enterFrom="opacity-0"
                                                                                enterTo="opacity-100"
                                                                                leave="ease-in duration-100"
                                                                                leaveFrom="opacity-100"
                                                                                leaveTo="opacity-0"
                                                                            >
                                                                                <div className="fixed inset-0" />
                                                                            </Transition.Child>
                                                                            <div id="slideIn_down_modal" className="fixed inset-0 z-[999] overflow-y-auto bg-black/20">
                                                                                <div className="flex min-h-screen items-start justify-center px-4">
                                                                                    <Dialog.Panel className="panel animate__animated animate__slideInDown my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                                                                        <div className="flex items-center justify-between bg-white px-5 py-3 dark:bg-white border-b">
                                                                                            <h5 className="text-lg font-bold">Book School Hotel</h5>
                                                                                            <button onClick={() => setModal10(false)} type="button" className="text-white-dark hover:text-dark">
                                                                                                <IconX />
                                                                                            </button>
                                                                                        </div>
                                                                                        {/* <iframe
                                                                        width="560"
                                                                        height="315"
                                                                        // src="https://www.youtube.com/embed/N2d7puNyPqw"
                                                                        src=".././public/assets/crown-logo.png"
                                                                        title="Video Title"
                                                                        //  frameBorder="0"

                                                                        allowFullScreen
                                                                        className="p-6 w-full "
                                                                    ></iframe> */}
                                                                                        <ReactPlayer
                                                                                            url="https://youtu.be/N2d7puNyPqw?si=fKY2WghPTEFRzlpR"
                                                                                            controls
                                                                                            width="700"
                                                                                            height="800"
                                                                                            className="p-4"
                                                                                        />

                                                                                        <ReactAudioPlayer src="https://instafollowers.c1.is/jaragandi.mp3" controls />

                                                                                        {/* <img ref={imgRef} src={img} alt="" width="400px" height="300px" />
                                                                            <button onClick={handleDownload}>Download Image</button>
                                                                            <button onClick={downloadPdf}>Download PDF</button> */}

                                                                                        {/* <div className="p-5 ">
                                                                                <div className="font-bold flex items-center justify-center">School Hostel</div>
                                                                                <div className="font-bold flex items-center justify-center">Combine Hostel</div>
                                                                                <div className="font-bold flex items-center justify-center">Balaji Hostel</div>
                                                                            </div>
                                                                            <div className="mb-5 mr-0 ml-6 flex items-center ">
                                                                                <div className="max-w-[19rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-white-light dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
                                                                                    <div className="py-7 px-6">
                                                                                        <h5 className="text-[#3b3f5c] text-xl font-semibold mb-4 dark:text-white-light border-b">Simple</h5>
                                                                                        <p className="text-white-dark">No Of Rooms:30</p>
                                                                                        <p className="text-white-dark">Max. Members per Rooms:5</p>
                                                                                        <p className="text-white-dark">Members filled:38</p>
                                                                                    </div>
                                                                                </div>
                                                                            </div> */}
                                                                                    </Dialog.Panel>
                                                                                </div>
                                                                            </div>
                                                                        </Dialog>
                                                                    </Transition>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}

                    {first && categ3 && (
                        <>
                            <div className="mt-4">
                                <div className="panel">
                                    <div className="table-responsive mb-5">
                                        <table className="table-hover">
                                            <thead>
                                                <tr>
                                                    <th>SL.NO</th>
                                                    <th>FILE TYPE</th>

                                                    <th className="text-center">ACTION</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {tableData.map((data) => {
                                                    return (
                                                        <tr key={data.id}>
                                                            <td>{data.id}</td>
                                                            <td>
                                                                <div className="whitespace-nowrap">{data.type}</div>
                                                            </td>

                                                            <td>
                                                                <div>
                                                                    <button onClick={() => setModal10(true)} type="button" className="border border-blue-400 rounded-md">
                                                                        <IconEye />
                                                                    </button>
                                                                    <Transition appear show={modal10} as={Fragment}>
                                                                        <Dialog as="div" open={modal10} onClose={() => setModal10(false)}>
                                                                            <Transition.Child
                                                                                as={Fragment}
                                                                                enter="ease-out duration-100"
                                                                                enterFrom="opacity-0"
                                                                                enterTo="opacity-100"
                                                                                leave="ease-in duration-100"
                                                                                leaveFrom="opacity-100"
                                                                                leaveTo="opacity-0"
                                                                            >
                                                                                <div className="fixed inset-0" />
                                                                            </Transition.Child>
                                                                            <div id="slideIn_down_modal" className="fixed inset-0 z-[999] overflow-y-auto bg-black/20">
                                                                                <div className="flex min-h-screen items-start justify-center px-4">
                                                                                    <Dialog.Panel className="panel animate__animated animate__slideInDown my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                                                                        <div className="flex items-center justify-between bg-white px-5 py-3 dark:bg-white border-b">
                                                                                            <h5 className="text-lg font-bold">Book School Hotel</h5>
                                                                                            <button onClick={() => setModal10(false)} type="button" className="text-white-dark hover:text-dark">
                                                                                                <IconX />
                                                                                            </button>
                                                                                        </div>
                                                                                        {/* <iframe
                                                                        width="560"
                                                                        height="315"
                                                                        // src="https://www.youtube.com/embed/N2d7puNyPqw"
                                                                        src=".././public/assets/crown-logo.png"
                                                                        title="Video Title"
                                                                        //  frameBorder="0"

                                                                        allowFullScreen
                                                                        className="p-6 w-full "
                                                                    ></iframe> */}
                                                                                        <ReactPlayer
                                                                                            url="https://youtu.be/N2d7puNyPqw?si=fKY2WghPTEFRzlpR"
                                                                                            controls
                                                                                            width="700"
                                                                                            height="800"
                                                                                            className="p-4 w-full h-full"
                                                                                        />

                                                                                        {/* <img ref={imgRef} src={img} alt="" width="400px" height="300px" />
                                                                            <button onClick={handleDownload}>Download Image</button>
                                                                            <button onClick={downloadPdf}>Download PDF</button> */}

                                                                                        {/* <div className="p-5 ">
                                                                                <div className="font-bold flex items-center justify-center">School Hostel</div>
                                                                                <div className="font-bold flex items-center justify-center">Combine Hostel</div>
                                                                                <div className="font-bold flex items-center justify-center">Balaji Hostel</div>
                                                                            </div>
                                                                            <div className="mb-5 mr-0 ml-6 flex items-center ">
                                                                                <div className="max-w-[19rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-white-light dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
                                                                                    <div className="py-7 px-6">
                                                                                        <h5 className="text-[#3b3f5c] text-xl font-semibold mb-4 dark:text-white-light border-b">Simple</h5>
                                                                                        <p className="text-white-dark">No Of Rooms:30</p>
                                                                                        <p className="text-white-dark">Max. Members per Rooms:5</p>
                                                                                        <p className="text-white-dark">Members filled:38</p>
                                                                                    </div>
                                                                                </div>
                                                                            </div> */}
                                                                                    </Dialog.Panel>
                                                                                </div>
                                                                            </div>
                                                                        </Dialog>
                                                                    </Transition>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}

                    {first && categ4 && (
                        <>
                            <div className="mt-4">
                                <div className="panel">
                                    <div className="table-responsive mb-5">
                                        <table className="table-hover">
                                            <thead>
                                                <tr>
                                                    <th>SL.NO</th>
                                                    <th>FILE TYPE</th>

                                                    <th className="text-center">ACTION</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {tableData.map((data) => {
                                                    return (
                                                        <tr key={data.id}>
                                                            <td>{data.id}</td>
                                                            <td>
                                                                <div className="whitespace-nowrap">{data.type}</div>
                                                            </td>

                                                            <td>
                                                                <div>
                                                                    <button onClick={() => setModal10(true)} type="button" className="border border-blue-400 rounded-md">
                                                                        <IconEye />
                                                                    </button>
                                                                    <Transition appear show={modal10} as={Fragment}>
                                                                        <Dialog as="div" open={modal10} onClose={() => setModal10(false)}>
                                                                            <Transition.Child
                                                                                as={Fragment}
                                                                                enter="ease-out duration-100"
                                                                                enterFrom="opacity-0"
                                                                                enterTo="opacity-100"
                                                                                leave="ease-in duration-100"
                                                                                leaveFrom="opacity-100"
                                                                                leaveTo="opacity-0"
                                                                            >
                                                                                <div className="fixed inset-0" />
                                                                            </Transition.Child>
                                                                            <div id="slideIn_down_modal" className="fixed inset-0 z-[999] overflow-y-auto bg-black/20">
                                                                                <div className="flex min-h-screen items-start justify-center px-4">
                                                                                    <Dialog.Panel className="panel animate__animated animate__slideInDown my-8 w-full max-w-lg overflow-hidden rounded-lg border-0 p-0 text-black dark:text-white-dark">
                                                                                        <div className="flex items-center justify-between bg-white px-5 py-3 dark:bg-white border-b">
                                                                                            <h5 className="text-lg font-bold">Book School Hotel</h5>
                                                                                            <button onClick={() => setModal10(false)} type="button" className="text-white-dark hover:text-dark">
                                                                                                <IconX />
                                                                                            </button>
                                                                                        </div>
                                                                                        {/* <iframe
                                                                        width="560"
                                                                        height="315"
                                                                        // src="https://www.youtube.com/embed/N2d7puNyPqw"
                                                                        src=".././public/assets/crown-logo.png"
                                                                        title="Video Title"
                                                                        //  frameBorder="0"

                                                                        allowFullScreen
                                                                        className="p-6 w-full "
                                                                    ></iframe> */}

                                                                                        <img ref={imgRef} src={img} alt="" width="400px" height="300px" />
                                                                                        {/* <button onClick={handleDownload}>Download Image</button>
                                                                            <button onClick={downloadPdf}>Download PDF</button> */}

                                                                                        {/* <div className="p-5 ">
                                                                                <div className="font-bold flex items-center justify-center">School Hostel</div>
                                                                                <div className="font-bold flex items-center justify-center">Combine Hostel</div>
                                                                                <div className="font-bold flex items-center justify-center">Balaji Hostel</div>
                                                                            </div>
                                                                            <div className="mb-5 mr-0 ml-6 flex items-center ">
                                                                                <div className="max-w-[19rem] w-full bg-white shadow-[4px_6px_10px_-3px_#bfc9d4] rounded border border-white-light dark:border-[#1b2e4b] dark:bg-[#191e3a] dark:shadow-none">
                                                                                    <div className="py-7 px-6">
                                                                                        <h5 className="text-[#3b3f5c] text-xl font-semibold mb-4 dark:text-white-light border-b">Simple</h5>
                                                                                        <p className="text-white-dark">No Of Rooms:30</p>
                                                                                        <p className="text-white-dark">Max. Members per Rooms:5</p>
                                                                                        <p className="text-white-dark">Members filled:38</p>
                                                                                    </div>
                                                                                </div>
                                                                            </div> */}
                                                                                    </Dialog.Panel>
                                                                                </div>
                                                                            </div>
                                                                        </Dialog>
                                                                    </Transition>
                                                                </div>
                                                            </td>
                                                        </tr>
                                                    );
                                                })}
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        </>
                    )}
                    {second && categ1 && (
                        <>
                            <p>hello</p>
                        </>
                    )}

                    {second && categ2 && (
                        <>
                            <p>second cat2</p>
                        </>
                    )}
                    {second && categ3 && (
                        <>
                            <p>second cat3</p>
                        </>
                    )}
                    {second && categ4 && (
                        <>
                            <p>second cat4</p>
                        </>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Skin;
