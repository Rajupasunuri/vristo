import React, { useEffect, useState } from 'react';
import axios from 'axios';


const OnlinePay = () => {
  const [formData, setFormData] = useState({
    amount: '',
    name: '',
    email: '',
    phone: '',
  });

  const [transactionID,setTransactionID] = useState<any>(null)
  const [hash,setHash] = useState<any>(null)
  const [key,setKey] = useState<any>('2oXOOcz6')



  function generateTransactionID(){
    const timestamp = Date.now()
    const randomNum = Math.floor(Math.random()*1000000)
    const merchantPrefix = 'T';
    const transactionID = `${merchantPrefix}${timestamp}${randomNum}`;
    return setTransactionID(transactionID)

  }

  const handleChange = (e:any) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e:any) => {
    e.preventDefault();
    try {
      const response = await axios.post('http://localhost:8081/api/payment', {...formData,transactionid:transactionID});
      const {  params } = response.data;

      setHash(params.hash)
      setTransactionID(params.txnid)
      // Redirect to PayU payment page
     // window.location.href = `${payuURL}?${new URLSearchParams(params)}`;
    } catch (error) {
      console.error('Payment initiation failed', error);
    }
  };

  useEffect(()=>{
    generateTransactionID()
  },[])

  return (
    <>
    <form onSubmit={handleSubmit}>
      <input
        type="text"
        name="amount"
        value={formData.amount}
        onChange={handleChange}
        placeholder="Amount"
      />
      <input
        type="text"
        name="name"
        value={formData.name}
        onChange={handleChange}
        placeholder="Name"
      />
      <input
        type="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
        placeholder="Email"
      />
      {/* <input
        type="text"
        name="phone"
        value={formData.phone}
        onChange={handleChange}
        placeholder="Phone"
      /> */}
      <button type="submit">check</button>
    </form>

    <form action='https://secure.payu.in/_payment' method='POST'>
       <input
        type="hidden"
        name="key"
        value={key}
        
      />
       <input
        type="hidden"
        name="txnid"
        value={transactionID}
        
      />
       <input
        type="hidden"
        name="amount"
        value={formData.amount}
        
      />
       <input
        type="hidden"
        name="productinfo"
        value='ProductInfo'
        
      />
      <input
        type="hidden"
        name="firstname"
        value={formData.name}
        
      />
      <input
        type="hidden"
        name="email"
        value={formData.email}
       
      />
      {/* <input
        type="hidden"
        name="phone"
        value={formData.phone}
        
      /> */}
      <input
        type="hidden"
        name="surl"
        value='http://localhost:8081/success'
        
      />
      <input
        type="hidden"
        name="furl"
        value='http://localhost:8081/failure'
        
      />
      <input
        type="hidden"
        name="hash"
        value={hash}
        
      />
      <button type='submit'>pay now</button>

    </form>
    </>
  );
};

export default OnlinePay;
