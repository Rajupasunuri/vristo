import { useEffect, useState } from 'react';
import { FaArrowRight } from 'react-icons/fa6';
import { PiArrowElbowRight } from 'react-icons/pi';
import { Link } from 'react-router-dom';
import { MY_INVOICE_PAY_URL, MY_PAYU_HASH_URL, MY_PAY_NOW_URL } from './query';
import axios from 'axios';
import Swal from 'sweetalert2';
const Invoice_pay = () => {
    const [selectedGateway, setSelectedGateway] = useState(null);
    const [payuselected, setPayuSelected] = useState(false);
    const [paygselected, setPaygSelected] = useState(false);
    const [axisselected, setAxisSelected] = useState(false);
    const [axis, setAxis] = useState(0);
    const [payg, setPayg] = useState(0);
    const [payu, setPayu] = useState(0);
    const [payuHashResponse, setPayuHashResponse] = useState<any>();
    const [paygHashResponse, setPaygHashResponse] = useState<any>();
    const [axisHashResponse, setAxisHashResponse] = useState<any>();
    const [hitPayuHash, setHitPayuHash] = useState(false);
    const [hitPaygHash, setHitPaygHash] = useState(false);
    const [hitAxisPayHash, setHitAxisPayHash] = useState(false);
    const [transactionID,setTransactionID] = useState<any>(null)
    const [transID,setTransID] = useState<any>(null)
    const [hash,setHash] = useState<any>(null)
    const [keys,setKey] = useState<any>('2oXOOcz6')
    const [togglepay,setTogglepay] = useState<any>(true)

    const handleGatewaySelection = (gateway: any) => {
        if (gateway == 'payu') {
            setPayuSelected(true);
            setPaygSelected(false);
            setAxisSelected(false);
        } else if (gateway == 'payg') {
            setPayuSelected(false);
            setPaygSelected(true);
            setAxisSelected(false);
        } else if (gateway == 'axispay') {
            setPayuSelected(false);
            setPaygSelected(false);
            setAxisSelected(true);
        }
        setSelectedGateway(gateway);
    };


    const [formData, setFormData] = useState({
    amount: localStorage.amount_due,
    name: localStorage.std_name,
    email: 'rajupasunuri1999@gmail.com',
    phone: localStorage.std_phone,
    studentID: localStorage.studentID,
    schoolID: localStorage.schoolID,
    schoolyearID: localStorage.schoolyearID,
    admno: localStorage.std_regno,
    invoiceID: localStorage.InvoiceID,
  });


   useEffect(() => {
    const InvoicePay = async () => {
      try {
        const headers = {
          'Content-Type': 'application/json',
          Authorization: localStorage.token,
        };
        const postData = {
          studentID: localStorage.studentID,
          schoolID: localStorage.schoolID,

          // schoolyearID: localStorage.schoolyearID,
        };
        const response = await axios.post(MY_INVOICE_PAY_URL, postData, {
          headers: headers,
        });

        if (response.data.error) {
          // Swal.fire('Request Failed, Try Again Later!');
        } else {
          console.log('INVOICE PAY', response);

          setAxis(response.data.data.gateways.axis);
          setPayg(response.data.data.gateways.payg);
          setPayu(response.data.data.gateways.payu);
        }
      } catch (error) {
        console.error('Error fetching data:', error);
      }
    };

    // Call the fetchData function when the component mounts
    InvoicePay();
  }, []);
 

    const payuHash = () => {
        const headers = {
            'Content-Type': 'application/json',
            Authorization: localStorage.token,
        };

        // const postData = {
           
        //     email: 'rajupasunuri1999@gmail.com',
            
        //     amount: localStorage.amount_due,
        //     firstname: localStorage.std_name,
        //     transactionID:transactionID,
        //     studentID: localStorage.studentID,
        //     schoolID: localStorage.schoolID,
        //     schoolyearID: localStorage.schoolyearID,
        //     admno: localStorage.std_regno,
        //     invoiceID: localStorage.InvoiceID,
        // };

        axios
            .post("http://localhost:8081/api/payment", {...formData,transactionid:transactionID},{
                headers:headers
            })
            .then((response) => {
                // console.log('payu hash', response.data);

                // if (response.data.error) {
                //     Swal.fire('Request Failed, Try Again Later!');
                // } else {
                //     console.log('payu hash', response);
                //     setPayuHashResponse(response.data.data.payu);
                //     setHitPayuHash(true);
                // }
                 const {  params } = response.data;
                 console.log("params",params)
                 console.log("params hash",params.hash)
                 setHash(params.hash)
                 setTransactionID(params.txnid)
                 setTogglepay(false)
            })
            .catch((err: any) => {
                console.log('payu error', err);
            });
    };

    const paygHash = () => {
        const headers = {
            'Content-Type': 'application/json',
            Authorization: localStorage.token,
        };

        const postData = {
            studentID: localStorage.studentID,
            schoolID: localStorage.schoolID,
            schoolyearID: localStorage.schoolyearID,
            admno: localStorage.std_regno,
            invoiceID: localStorage.InvoiceID,
        };

        axios
            .post(MY_PAYU_HASH_URL, postData, {
                headers: headers,
            })
            .then((response) => {
                // console.log('payu hash', response.data);

                if (response.data.error) {
                    Swal.fire('Request Failed, Try Again Later!');
                } else {
                    console.log('payu hash', response);
                    setPaygHashResponse(response.data.data.payg);
                    setHitPaygHash(true);
                }
            })
            .catch((err: any) => {
                console.log('payu error', err);
            });
    };

    const axisPayHash = () => {
        const headers = {
            'Content-Type': 'application/json',
            //Authorization: localStorage.token,
        };

        const postData = {
            studentID: localStorage.studentID,
            schoolID: localStorage.schoolID,
            schoolyearID: localStorage.schoolyearID,
            admno: localStorage.std_regno,
            invoiceID: localStorage.InvoiceID,
        };

        axios
            .post(MY_PAYU_HASH_URL, postData, {
                headers: headers,
            })
            .then((response) => {
                // console.log('payu hash', response.data);

                if (response.data.error) {
                    Swal.fire('Request Failed, Try Again Later!');
                } else {
                    console.log('payu hash', response);
                    setAxisHashResponse(response.data.data.axispay);
                    setHitAxisPayHash(true);
                }
            })
            .catch((err: any) => {
                console.log('payu error', err);
            });
    };

    function generateTransactionID(){
    const timestamp = Date.now()
    const randomNum = Math.floor(Math.random()*1000000)
    const merchantPrefix = 'T';
    const transactionID = `${merchantPrefix}${timestamp}${randomNum}`;
    return setTransactionID(transactionID)

  }

  useEffect(()=>{
    generateTransactionID()
  },[])

  
    return (
        <div>
            <div>{togglepay&&<> <h2 className="text-lg font-bold mb-4">Select Payment GateWay</h2>
            <div className="panel flex-col space-y-4">
                <div className=" flex justify-between items-center">
                    {payu > 0 && (
                        <div className={`${payuselected && 'scale-125'}`}>
                            <img className={`w-19 h-12  cursor-pointer`} src="/assets/images/payu.png" alt="logo" onClick={() => handleGatewaySelection('payu')} />
                            {/* <PiArrowElbowRight className="text-green-600 text-lg font-bold absolute  top-[40%] right-[40%]" /> */}
                        </div>
                    )}
                    {payg > 0 && (
                        <div className={`${selectedGateway == 'payg' && paygselected && 'scale-125'}`}>
                            <img className="w-19 h-12  cursor-pointer  " src="/assets/images/payg.png" alt="logo" onClick={() => handleGatewaySelection('payg')} />
                        </div>
                    )}
                    {axis > 0 && (
                        <div className={`${selectedGateway == 'axispay' && axisselected && 'scale-125'}`}>
                            <img className="w-19 h-10 cursor-pointer " src="/assets/images/axisPay.png" alt="logo" onClick={() => handleGatewaySelection('axispay')} />
                        </div>
                    )}
                </div>
            </div>
            {payuselected && (
                <div className=" flex justify-center items-center mt-6">
                    <form onSubmit={payuHash}>
      <input
        type="hidden"
        name="amount"
      
        value={localStorage.amount_due}
       
        placeholder="Amount"
      />
      <input
        type="hidden"
        name="name"
        value={localStorage.std_name}
        
        placeholder="Name"
      />
      <input
        type="hidden"
        name="email"
        
        value='rajupasunuri1999@gmail.com'
        
        placeholder="Email"
      />
      <input
        type="hidden"
        name="phone"
        
        value={formData.phone}
        
        placeholder="Phone"
      />
       <button type="button" onClick={payuHash} className="btn btn-success btn-sm text-lg ">
                        Proceed With Payu <FaArrowRight className="text-white ml-2" />
                    </button>
    </form>
                   
                </div>
            )}
            {paygselected && (
                <div className=" flex justify-center items-center mt-6">
                    <button type="button" onClick={paygHash} className="btn btn-success text-lg">
                        Proceed With Payg <FaArrowRight className="text-white ml-2" />
                    </button>
                </div>
            )}
            {axisselected && (
                <div className=" flex justify-center items-center mt-6">
                    <button type="button" onClick={axisPayHash} className="btn btn-success text-lg">
                        Proceed With Axis <FaArrowRight className="text-white ml-2" />
                    </button>
                </div>
            )}</>}</div>
            


            
             {!togglepay&&<div className=" panel  bg-white shadow-md rounded-md p-6 mt-10">
            <div className="flex items-center justify-between mb-6">
                <div>
                    <img src={localStorage.school_logo} alt="School Logo" className="w-20 h-auto" />
                </div>
                <div>
                    <h1 className="text-lg font-bold">Invoice : {localStorage.InvoiceID}</h1>
                   
                    <p>Date: {new Date().toLocaleDateString('en-GB')}</p>
                </div>
            </div>
            
            <div className="mt-6 ">
                <h2 className="text-lg font-semibold">Payment Details</h2>
                <div className='table-responsive'>
                <table className="w-full mt-3 ">
                    <thead>
                        <tr>
                            <th className="border px-4 py-2">Description</th>
                            <th className="border px-4 py-2">Amount</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td className="border px-4 py-2">Name</td>
                            <td className="border px-4 py-2">{localStorage.std_name}</td>
                        </tr>
                        <tr>
                            <td className="border px-4 py-2">Email</td>
                            <td className="border px-4 py-2">rajupasunuri1999@gmail.com</td>
                        </tr>
                        <tr>
                            <td className="border px-4 py-2">StudentID</td>
                            <td className="border px-4 py-2"> {localStorage.studentID}</td>
                        </tr>
                        <tr>
                            <td className="border px-4 py-2">SchoolID</td>
                            <td className="border px-4 py-2"> {localStorage.schoolID}</td>
                        </tr>
                        <tr>
                            <td className="border px-4 py-2">School yearID</td>
                            <td className="border px-4 py-2">{localStorage.schoolyearID}</td>
                        </tr>
                        <tr>
                            <td className="border px-4 py-2">Admno</td>
                            <td className="border px-4 py-2">{localStorage.std_regno}</td>
                        </tr>
                        <tr>
                            <td className="border px-4 py-2">InvoiceID</td>
                            <td className="border px-4 py-2">{localStorage.InvoiceID}</td>
                        </tr>
                        <tr>
                            <td className="border px-4 py-2">Due amount</td>
                            <td className="border px-4 py-2">{localStorage.amount_due}</td>
                        </tr>
                       
                    </tbody>
                </table>
                </div>
            </div>
            <div className="mt-6">
                <form action='https://secure.payu.in/_payment' method='POST'>
    <input
        type="hidden"
        name="key"
        value={keys}
        
      />
       <input
        type="hidden"
        name="txnid"
        value={transactionID}
        
      />
       <input
        type="hidden"
        name="amount"
        value={formData.amount}
        
      />
       <input
        type="hidden"
        name="productinfo"
        value='ProductInfo'
        
      />
      <input
        type="hidden"
        name="firstname"
        value={formData.name}
        
      />
      <input
        type="hidden"
        name="email"
        value={formData.email}
       
      />
      <input
        type="hidden"
        name="phone"
        value={formData.phone}
        
      />
      <input
        type="hidden"
        name="surl"
        value='http://localhost:8081/success'
        
      />
      <input
        type="hidden"
        name="furl"
        value='http://localhost:8081/failure'
        
      />
      <input
        type="hidden"
        name="hash"
        value={hash}
        
      />
    <button type='submit' className='btn btn-secondary w-full'>Pay now</button>
</form>

                
                
            </div>
             </div>}
        </div>
    );
};

export default Invoice_pay;
