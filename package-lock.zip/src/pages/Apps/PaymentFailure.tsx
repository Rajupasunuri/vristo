import axios from 'axios';
import { MY_DASHBOARD_URL } from './query';
import { useEffect } from 'react';
import Timetable from './Timetable';
import AffordabilityWidget from './Timetable';
import { Link } from 'react-router-dom';

const PaymentFailure = () => {
   
    return (
       <>
      <div className='flex flex-col justify-center items-center    space-y-4 h-screen w-full'>
         <h1 className='text-danger font-bold text-lg'>Payment Failed</h1>
         <Link to='/paynow'><button className='btn btn-primary'>Back to payments</button></Link>
      </div>
       </>
    );
};

export default PaymentFailure;
