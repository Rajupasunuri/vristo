import { DataTableSortStatus } from 'mantine-datatable';
import { useEffect, useState } from 'react';
import sortBy from 'lodash/sortBy';
import { downloadExcel } from 'react-export-table-to-excel';
import { useDispatch } from 'react-redux';
import { setPageTitle } from '../../store/themeConfigSlice';
import IconPrinter from '../../components/Icon/IconPrinter';
import html2canvas from 'html2canvas';
import jsPDF from 'jspdf';
import { MY_STUDENT_MARKS_URL } from './query';
import axios from 'axios';



const Marks = () => {
    const dispatch = useDispatch();

    useEffect(() => {
        const fetchData = async () => {
            try {
                const headers = {
                    'Content-Type': 'application/json',
                    Authorization: localStorage.token,
                };
                const postData = {
                    studentID: localStorage.studentID,
                    schoolID: localStorage.schoolID,
                    schoolyearID: localStorage.schoolyearID,
                };
                const response = await axios.get('http://localhost:8081/signup');

                console.log('student marks', response);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        // Call the fetchData function when the component mounts
        fetchData();
    }, []);

    const exportTable = (type: any) => {
        window.print();
    };

    return (
        <div>
            <div className="panel mt-6 ">
                <div className="flex  justify-between items-center flex-wrap border-b-2 mb-4 pb-4 print:hidden">
                    {/* <button type="button" onClick={() => exportTable('csv')} className="btn btn-primary btn-sm m-1 ">
                            <IconFile className="w-5 h-5 ltr:mr-2 rtl:ml-2" />
                            CSV
                        </button>
                        <button type="button" onClick={() => exportTable('txt')} className="btn btn-primary btn-sm m-1">
                            <IconFile className="w-5 h-5 ltr:mr-2 rtl:ml-2" />
                            TXT
                        </button>

                        <button type="button" className="btn btn-primary btn-sm m-1" onClick={handleDownloadExcel}>
                            <IconFile className="w-5 h-5 ltr:mr-2 rtl:ml-2" />
                            EXCEL
                        </button> */}
                    <div>
                        <h4 className="text-base font-bold">Marks</h4>
                    </div>
                    <button type="button" onClick={() => exportTable('print')} className="btn btn-primary btn-sm m-1">
                        <IconPrinter className="ltr:mr-2 rtl:ml-2 " />
                        PRINT
                    </button>
                    {/* <button onClick={downloadPDF}>pdf</button> */}
                </div>

                <div className="datatables  " id="table-container">
                    <div className="flex justify-center items-center mb-4">
                        <img src="public\assets\images\C2172.jpg" alt="Image" />
                    </div>
                    <div>
                        <h4 className=" font-normal text-lg mb-4">Marks Information</h4>
                    </div>

                    <div className="table-responsive">
                        <table className="table-hover table-striped  border border-collapse ">
                            <thead></thead>
                            <tbody>
                                <tr>
                                    <td className="">Subjects</td>
                                    <td colSpan={2} className=" ">
                                        I MID Exam
                                    </td>
                                    <td colSpan={2} className="">
                                        II MID Exam
                                    </td>
                                    <td colSpan={2} className="">
                                        Quaterly Exam
                                    </td>
                                </tr>
                                <tr>
                                    <td className=" ">Max Marks</td>
                                    <td>Max</td>
                                    <td>Actual</td>
                                    <td>Max</td>
                                    <td>Actual</td>
                                    <td>Max</td>
                                    <td>Actual</td>
                                </tr>
                                <tr>
                                    <td className="border">Biology</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Chemistry</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">English</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Geography</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Hindi</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">History & Civics</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Maths</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Physics</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Telugu</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Total</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Average</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                                <tr>
                                    <td className="border">Grade</td>
                                    <td>50</td>
                                    <td>53</td>
                                    <td>50</td>
                                    <td>35</td>
                                    <td>50</td>
                                    <td>40</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Marks;


// const Marks = () => {

//      const cellStyle = {
//     border: '1px solid black',
//     padding: '8px'
//   };
//   return (
//     <table className=' table-responsive   ' style={{ width: '100%', textAlign: 'center', borderCollapse: 'collapse',border:'',borderTop:'none' }}>
       
//       <thead>
//          <tr >
//             <td>Name:Raju Pasunuri</td>
//             <td>Name:Raju Pasunuri</td>
//             <td>Name:Raju Pasunuri</td>
//             <td>Name:Raju Pasunuri</td>
//         </tr>
//         <tr>
//           <th style={cellStyle}>Date</th>
//           <th style={cellStyle}>Subject</th>
//           <th style={cellStyle}>Time</th>
//           <th style={cellStyle}>Inv Sign</th>
//         </tr>
//       </thead>
//       <tbody>
      
//         <tr>
//           <td style={cellStyle}>rajesh</td>
//           <td style={cellStyle}>rajesh</td>
//           <td style={cellStyle}>rajesh</td>
//           <td style={cellStyle}>rajesh</td>
//         </tr>
//         <tr>
//           <td style={cellStyle}>rajesh</td>
//           <td style={cellStyle}>rajesh</td>
//           <td style={cellStyle}>rajesh</td>
//           <td style={cellStyle}>rajesh</td>
//         </tr>
//       </tbody>
//     </table>
//   );
// }

// export default Marks;


// import { useEffect } from 'react';
// import { useDispatch, useSelector } from 'react-redux';
// import { setPageTitle } from '../../store/themeConfigSlice';
// import html2canvas from 'html2canvas';
// import jsPDF from 'jspdf';
// import { IRootState } from '../../store';



// const Marks = () => {
    
//     const dispatch = useDispatch();
//     const school_logo = useSelector((state: IRootState) => state.themeConfig.school_logo);
//     const studentdtls = useSelector((state: IRootState) => state.themeConfig);
   
//     useEffect(() => {
//         dispatch(setPageTitle('Invoice Preview'));
//     });
   

 

//     // const downloadPDF = () => {
        
//     //         const input = document.getElementById('table-container');
//     //         if (!input) {
//     //             console.error("Element with ID 'table-container' not found.");
//     //             return;
//     //         }

//     //             html2canvas(input, { scale: 2 })
//     //                 .then((canvas) => {
//     //                     const pdf = new jsPDF('p', 'mm', 'a4');
//     //                     const imgData = canvas.toDataURL('image/png');
//     //                     const imgWidth = 210;
//     //                     const imgHeight = (canvas.height * imgWidth) / canvas.width;
//     //                     const pdfHeight = (imgHeight * 210) / imgWidth;
//     //                     const margin = 1; // Adjust margin as needed
//     //                     const padding = 10;

//     //                     const xPos = 16; // Adjust as needed
//     //                     const yPos = 10; // Adjust as needed
//     //                     const contentWidth = imgWidth - 30 * 1;
//     //                     const contentHeight = pdfHeight - 2 * padding;
//     //                     pdf.addImage(imgData, 'PNG', xPos, yPos, contentWidth, contentHeight);
//     //                     pdf.save('Fee Receipt.pdf');
//     //                 })
//     //                 .catch((error) => {
//     //                     console.error('Error generating canvas:', error);
//     //                 });
            

           
        
//     // };


//  const downloadPDF = () => {
//         console.log("Download PDF button clicked");
//         const input = document.getElementById('table-container');
//         if (!input) {
//             console.error("Element with ID 'table-container' not found.");
//             return;
//         }

//         html2canvas(input, { scale: 2 })
//             .then((canvas) => {
//                 console.log("Canvas generated successfully:", canvas);
//                 const pdf = new jsPDF('p', 'mm', 'a4');
//                 const imgData = canvas.toDataURL('image/png');
//                 const xPos = 16; // Adjust as needed
//                 const yPos = 10; // Adjust as needed
//                 const contentWidth = 210; // Adjust as needed
//                 const contentHeight = (canvas.height * contentWidth) / canvas.width;
//                 pdf.addImage(imgData, 'PNG', xPos, yPos, contentWidth, contentHeight);
//                 pdf.save('Fee Receipt.pdf');
//             })
//             .catch((error) => {
//                 console.error('Error generating canvas:', error);
//             });
//     };













//     return (
//         <div className="">
//             <div className="flex justify-start flex-wrap gap-4 mb-6 print:hidden">
//                 <button type="button" onClick={downloadPDF} className="btn btn-success btn-sm gap-2">
//                     Download PDF
//                 </button>
//                 {/* <button type="button" onClick={() => setFeeReceipt(false)} className="btn btn-success gap-2">
//                     Back
//                 </button> */}
//             </div>
//             <div className=" bg-white shadow-md rounded-md w-[1200px] h-full p-12 pt-16  text-base border-gray-400 border-2" id="table-container">
//                 {/* Rest of the code remains unchanged */}

//                 <div className="flex justify-center items-center flex-col flex-wrap ">
//                     <div className="">
//                         <img src='https://crown-school-site.s3.ap-south-1.amazonaws.com/images/crown-logo_20062022_1655713908.png' className="mx-auto w-16 h-12" alt="Image Description" />
//                     </div>
                    
//                 </div>
                
                 
                
             
//             </div>
//         </div>
//     );
// };

// export default Marks;

