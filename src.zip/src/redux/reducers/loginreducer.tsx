// reducer.js
/*import { FETCH_USER_SUCCESS } from '../actions/actionconstants';

const initialState = {
  user: null,
};

export const userReducer = (state = initialState,action: { type: any; payload: any; }) => {
  switch (action.type) {
    case FETCH_USER_SUCCESS:
      return {
        ...state,
        user: action.payload,
      };
      break
    default:
      return state;
  }
};
*/

