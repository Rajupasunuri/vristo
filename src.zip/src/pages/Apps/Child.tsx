const Child = () => {
    return (
        <div>
            <div className="pb-5 text-lg text-black font-bold">MI Of Your Child</div>
            <div className="panel h-18">
                <h2 className="text-base">NOTE: Date expired, Please contact to admin for the details.</h2>
            </div>
        </div>
    );
};

export default Child;
