import axios from 'axios';
import { useEffect } from 'react';
import { MY_INVOICE_PAY_URL } from '../query';

const PaymentPage = () => {
    return <div>Hello Payment page</div>;
};

export default PaymentPage;
