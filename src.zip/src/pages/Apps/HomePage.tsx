const HomePage = () => {
    return (
        <div>
            <h2>HEllo home page</h2>
        </div>
    );
};

export default HomePage;
