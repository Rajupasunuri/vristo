const PaymentGate = () => {
    return (
        <div>
            <h2>Payment GateWay</h2>
            <div className="panel">
                <h2>Hello payment gateway</h2>
            </div>
        </div>
    );
};

export default PaymentGate;
