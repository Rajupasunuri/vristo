/* eslint-disable */

export const MY_API_URL = 'https://stdapi.crownelearn.com/';

export const MY_LOGIN_URL = MY_API_URL + 'login/';
export const MY_PROFILE_URL = MY_API_URL + 'profile/';
export const MY_PROFILE_EDIT_URL = MY_API_URL + 'pedit/';
export const MY_DASHBOARD_URL = MY_API_URL + 'dashboard/';
export const USER_IMG = MY_API_URL + 'images/user.png';
export const NO_IMG = MY_API_URL + 'images/no-img.png';
export const SQ_IMG = MY_API_URL + 'images/sq-img.jpg';
export const V_IMG = MY_API_URL + 'images/v-img.jpg';
export const H_IMG = MY_API_URL + 'images/h-img.jpg';
