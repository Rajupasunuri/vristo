import { useNavigate } from 'react-router-dom';
import { useEffect, useState } from 'react';
import Swal from 'sweetalert2';


const PaymentFailure = () => {
   
     const navigate = useNavigate();
    

    

    const showAlert = async (type: any) => {
          if (type === "fail") {
            Swal.fire({
                icon: 'error',
                title: 'Oops...',
                text: 'Something went wrong!',
                padding: '2em',
                customClass: 'sweet-alerts',
                confirmButtonText: 'Go to payments',
                allowOutsideClick: false,
                
            }).then((result) => {
                if (result.isConfirmed) {
                  
                    navigate('/paynow');
                }
            });
        }
    };
    useEffect(()=>{
      showAlert("fail")
    },[])

    return (
        <></>
    );
};

export default PaymentFailure;

