//import { createStore } from "redux";
/*import { legacy_createStore as createStore} from 'redux'
import {userReducer} from "../redux/reducers/loginreducer";

const store = createStore,<>(
  userReducer,
  {},
 
);

export default store;*/