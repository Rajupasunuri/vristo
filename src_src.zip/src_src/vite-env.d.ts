/// <reference types="vite/client" />
// Extend the window interface to include SpeechRecognition and webkitSpeechRecognition
interface Window {
  SpeechRecognition: any;
  webkitSpeechRecognition: any;
}
declare module 'react-speech-kit';
