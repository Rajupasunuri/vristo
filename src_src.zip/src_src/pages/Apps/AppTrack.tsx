import axios from 'axios';
import React, { useEffect, useState } from 'react';

function AppTrack() {
  const [logs, setLogs] = useState<any>([]);
   const [appData, setAppData] = useState([]);

  // Fetch logs from the backend
//   useEffect(() => {
//    const fetchLogs = async () => {
//   try {
//     const response = await fetch('http://localhost:5000/logs');
    
//     if (!response.ok) {
//       throw new Error(`HTTP error! status: ${response.status}`);
//     }
    
//     const data = await response.json();
//     setLogs(data);
//   } catch (error) {
//     console.error('Error fetching logs:', error);
//   }
// };

//     // Poll the server every 5 seconds to update logs
//     const interval = setInterval(() => {
//       fetchLogs();
//     }, 5000);

//     // Cleanup on unmount
//     return () => clearInterval(interval);
//   }, []);

  useEffect( ()=>{
   const  headers={

    'Content-Type': 'application/json',

     }
     axios.get("http://localhost:5000/apps",{headers:headers})
     .then((response)=>{
        setAppData(response.data.data)
          console.log("log response",response)
     })
     .catch((err)=>{
      console.log("log error",err)
     })

  },[])
  

  return (
    // <div className="App">
    //   <h1>Application Usage Logs</h1>
    //   <table>
    //     <thead>
    //       <tr>
    //         <th>Process Name</th>
    //         <th>Start Time</th>
    //         <th>End Time</th>
    //       </tr>
    //     </thead>
    //     <tbody>
    //       {Object.entries(logs).map(([pid, log]:any) => (
    //         <tr key={pid}>
    //           <td>{log.name}</td>
    //           <td>{new Date(log.start_time).toLocaleString()}</td>
    //           <td>{log.end_time ? new Date(log.end_time).toLocaleString() : 'Running'}</td>
    //         </tr>
    //       ))}
    //     </tbody>
    //   </table>
    // </div>
     <div className="overflow-hidden ">
      <h1 className='mb-4 text-base font-bold'> Application Usage</h1>
      <div className='overflow-x-auto'>
         <table className="w-full  ">
        <thead>
          <tr>
            
            <th className="border px-4 py-2">App Name</th>
            <th className="border px-4 py-2">Start Time</th>
            <th className="border px-4 py-2">Close Time</th>
            <th className="border px-4 py-2">Duration</th>
          </tr>
        </thead>
        <tbody>
          {appData.map((app, index) => (
            <tr key={index} className="border px-4 py-2">
              <td className="border px-4 py-2">{app[0]}</td>
              <td className="border px-4 py-2">{app[2]}</td>
              <td className="border px-4 py-2">{app[3]}</td>
              <td className="border px-4 py-2">{app[4]}</td>
             
            </tr>
          ))}
        </tbody>
      </table>
      </div>
    </div>
  );
}

export default AppTrack;
