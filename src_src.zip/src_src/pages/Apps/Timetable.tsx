import { Tab } from '@headlessui/react';
import { Fragment, useEffect, useState } from 'react';
import { useDispatch } from 'react-redux';
import { setPageTitle } from '../../store/themeConfigSlice';
import 'tippy.js/dist/tippy.css';
import axios from 'axios';
import { MY_TIME_TABLE_URL } from './query';
import Swal from 'sweetalert2';

const Timetable = () => {
    const dispatch = useDispatch();

    const [all_tabs, setAll_tabs] = useState([]);
       const [selectedIndex, setSelectedIndex] = useState(0);
       const [today, setToday] = useState('');

    useEffect(() => {
        const fetchData = async () => {
            try {
                const headers = {
                    'Content-Type': 'application/json',
                    Authorization: localStorage.token,
                };
                const postData = {
                    studentID: localStorage.studentID,
                    schoolID: localStorage.schoolID,
                    classesID: localStorage.classesID,
                    sectionID: localStorage.sectionID,
                };
                const response = await axios.post(MY_TIME_TABLE_URL, postData, {
                    headers: headers,
                });

                if (response.data.error) {
                    Swal.fire('Request Failed, Try Again Later!');
                } else {
                    setAll_tabs(response.data.data.this_days);
                     const today = new Date().toLocaleString('en-us', { weekday: 'long' });
                     setToday(today);
                    const defaultIndex = response.data.data.this_days.findIndex((tab:any) => tab.day_name === today);
                    setSelectedIndex(defaultIndex !== -1 ? defaultIndex : 0); 
                }

                console.log('time table', response);
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        // Call the fetchData function when the component mounts
        fetchData();
    }, []);

    return (
        <div>
            
           <div className=''>
            {all_tabs.map((all_tab: any, index: number) => (
             <div key={index}>
             {all_tab.day_name===today&&<div key={index} className='panel mb-4 space-y-2'>
                 <div className="flex items-center justify-between dark:text-white-light mb-5">
                            <h5 className="font-semibold text-lg">Today Schedule</h5>
                        </div>
                 {all_tab.time_table.length>0?(<>   {all_tab.time_table.map((data: any, subIndex: number) => {
                          const [startTime, endTime] = data.start_time.split(' - ');
                        return(
                        <div key={subIndex}>
                             <div className="space-y-6">
                                
                                    <div
                                        
                                        className="flex bg-gray-100 p-2 cursor-pointer"
                                        
                                    >
                                        <span className="shrink-0 grid place-content-center text-sm w-9 h-9 rounded-md bg-success-light dark:bg-success text-success dark:text-success-light">
                                            Live
                                        </span>
                                        <div className="px-3 flex-1">
                                            <div>{data.subject_name}</div>
                                            <div className="text-xs text-white-dark dark:text-gray-500">{data.teacher_name}</div>
                                        </div>
                                        <span className="text-pink-500 text-sm px-1 ltr:ml-auto rtl:mr-auto whitespace-pre flex justify-center items-center">{startTime}<br/>{endTime}</span>
                                    </div>
                             
                            </div>


                         </div>

                       
                            

                        
                    )}
                )}</>):<div className='text-lg flex justify-center items-center font-semibold'>No Schedule Found</div>}

              </div>}
             </div>

           )) }
           </div>

           <div className='space-y-4'>
            {all_tabs.map((all_tab: any, index: number) => (
             <div key={index}>
             <div key={index} className='panel space-y-2'>
                 <div className="flex items-center justify-between dark:text-white-light mb-5">
                            <h5 className="font-semibold text-lg">{all_tab.day_name} Schedule</h5>
                        </div>
                   {all_tab.time_table.length>0?(<> {all_tab.time_table.map((data: any, subIndex: number) => {
                          const [startTime, endTime] = data.start_time.split(' - ');
                        return(
                        <div key={subIndex}>
                             <div className="space-y-6">
                                
                                    <div
                                        key={index}
                                        className="flex bg-gray-100 p-2 cursor-pointer"
                                        
                                    >
                                        <span className="shrink-0 grid place-content-center text-sm w-9 h-9 rounded-md bg-success-light dark:bg-success text-success dark:text-success-light">
                                            Live
                                        </span>
                                        <div className="px-3 flex-1">
                                            <div>{data.subject_name}</div>
                                            <div className="text-xs text-white-dark dark:text-gray-500">{data.teacher_name}</div>
                                        </div>
                                        <span className="text-pink-500 text-sm px-1 ltr:ml-auto rtl:mr-auto whitespace-pre flex justify-center items-center">{startTime}<br/>{endTime}</span>
                                    </div>
                             
                            </div>


                         </div>

                       
                            

                        
                    )}
                )}</>):<div className='text-lg flex justify-center items-center font-semibold'>No Schedule Found</div>}

              </div>
             </div>

           )) }
           </div>
        </div>
    );
};
export default Timetable;



