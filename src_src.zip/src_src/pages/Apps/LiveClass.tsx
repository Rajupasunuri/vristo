const LiveClass = () => {
    return (
        <>
            <div>hello Live class</div>
        </>
    );
};

export default LiveClass;
