import axios from 'axios';
import { MY_DASHBOARD_URL } from './query';
import { useEffect } from 'react';
import Timetable from './Timetable';
import AffordabilityWidget from './Timetable';

const Mi_Child = () => {
    useEffect(() => {
        const fetchData = async () => {
            try {
                const headers = {
                    'Content-Type': 'application/json',
                    Authorization: localStorage.token,
                };
                const postData = {
                    studentID: localStorage.studentID,
                    schoolID: localStorage.schoolID,
                };
                const response = await axios.post(MY_DASHBOARD_URL, postData, {
                    headers: headers,
                });

                console.log('dashboard', response);
                // if (response.data.error) {
                //     // setUsererror(response.data.message);
                // } else {
                //     const profiledtls = response.data.data;
                //     console.log('profiledtls:', profiledtls);

                //     // setProfile(profiledtls);
                // }
            } catch (error) {
                console.error('Error fetching data:', error);
            }
        };

        // Call the fetchData function when the component mounts
        fetchData();
    }, []);
    return (
        // <AffordabilityWidget key='2oXOOcz6' amount='10'/>

        <h1>hello child</h1>
    );
};

export default Mi_Child;
