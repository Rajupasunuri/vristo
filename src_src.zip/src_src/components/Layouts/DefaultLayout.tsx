import { PropsWithChildren, Suspense, useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import App from '../../App';
import { IRootState } from '../../store';
import { toggleSidebar } from '../../store/themeConfigSlice';
import Footer from './Footer';
import Header from './Header';
import Sidebar from './Sidebar';
import Portals from '../../components/Portals';

import PerfectScrollbar from 'react-perfect-scrollbar';
import IconHorizontalDots from '../../components/Icon/IconHorizontalDots';

import IconMoodSmile from '../../components/Icon/IconMoodSmile';
import IconSend from '../../components/Icon/IconSend';
import IconMicrophoneOff from '../../components/Icon/IconMicrophoneOff';
import IconDownload from '../../components/Icon/IconDownload';
import IconCamera from '../../components/Icon/IconCamera';
import axios from 'axios';
import IconChatDot from '../Icon/IconChatDot';

const DefaultLayout = ({ children }: PropsWithChildren) => {
    const themeConfig = useSelector((state: IRootState) => state.themeConfig);
    const dispatch = useDispatch();

    const [showLoader, setShowLoader] = useState(true);
    const [showTopButton, setShowTopButton] = useState(false);
    const [showChat, setShowChat] = useState(false);

    const goToTop = () => {
        document.body.scrollTop = 0;
        document.documentElement.scrollTop = 0;
    };

    const onScrollHandler = () => {
        if (document.body.scrollTop > 50 || document.documentElement.scrollTop > 50) {
            setShowTopButton(true);
        } else {
            setShowTopButton(false);
        }
    };

    useEffect(() => {
        window.addEventListener('scroll', onScrollHandler);

        const screenLoader = document.getElementsByClassName('screen_loader');
        if (screenLoader?.length) {
            screenLoader[0].classList.add('animate__fadeOut');
            setTimeout(() => {
                setShowLoader(false);
            }, 200);
        }

        return () => {
            window.removeEventListener('onscroll', onScrollHandler);
        };
    }, []);
    const [isShowChatMenu, setIsShowChatMenu] = useState(false);

    const [textMessage, setTextMessage] = useState('');

    const defaults = [
        {
            userid: 1,
            message: 'hello ',
        },
        {
            userid: 2,
            message: 'user2',
        },
    ];



    const [msgs, setMsgs] = useState(defaults);

    const scrollToBottom = () => {
        setTimeout(() => {
            const element: any = document.querySelector('.chat-conversation-box');
          if(element){
              element.behavior = 'smooth';
            element.scrollTop = element.scrollHeight;
          }
        });
    };

    const sendMessage = () => {
        if (textMessage.trim()) {
            // let user: any = list.find((d) => d.userId === selectedUser.userId);
            let user: any = [];
            user.push({
                userid: 1,
                message: textMessage,
                // time: 'Just now',
            });
            // setFilteredItems(list);
            setMsgs((prev) => [...prev, ...user]);
            const headers = {
                'Content-Type': 'application/json',
                // Authorization: localStorage.token,
            };
            const postData = {
                message: textMessage,
                student_id: 1,
            };

            axios
                .post('http://localhost:5000/chat', postData, {
                    headers: headers,
                })
                .then((res) => {
                    console.log('msg...', res);
                    const result = res.data;
                    setMsgs((prev) => [...prev, result]);
                })
                .catch((err) => {
                    console.log('msg err', err);
                });
            setTextMessage('');
            scrollToBottom();
        }
    };
    const sendMessageHandle = (event: any) => {
        if (event.key === 'Enter') {
            scrollTo();
            sendMessage();
        }
    };
    useEffect(() => {
        scrollToBottom();
    }, [msgs]);

    const handlechat=()=>{
        setShowChat(true)
    }
    const dates = new Date();
    const local = dates.toLocaleTimeString();

    return (
        <App>
            {/* BEGIN MAIN CONTAINER */}
            <div className="relative">
                {/* sidebar menu overlay */}
                <div className={`${(!themeConfig.sidebar && 'hidden') || ''} fixed inset-0 bg-[black]/60 z-50 lg:hidden`} onClick={() => dispatch(toggleSidebar())}></div>
                {/* screen loader */}
                {showLoader && (
                    <div className="screen_loader fixed inset-0 bg-[#fafafa] dark:bg-[#060818] z-[60] grid place-content-center animate__animated">
                        <svg width="64" height="64" viewBox="0 0 135 135" xmlns="http://www.w3.org/2000/svg" fill="#4361ee">
                            <path d="M67.447 58c5.523 0 10-4.477 10-10s-4.477-10-10-10-10 4.477-10 10 4.477 10 10 10zm9.448 9.447c0 5.523 4.477 10 10 10 5.522 0 10-4.477 10-10s-4.478-10-10-10c-5.523 0-10 4.477-10 10zm-9.448 9.448c-5.523 0-10 4.477-10 10 0 5.522 4.477 10 10 10s10-4.478 10-10c0-5.523-4.477-10-10-10zM58 67.447c0-5.523-4.477-10-10-10s-10 4.477-10 10 4.477 10 10 10 10-4.477 10-10z">
                                <animateTransform attributeName="transform" type="rotate" from="0 67 67" to="-360 67 67" dur="2.5s" repeatCount="indefinite" />
                            </path>
                            <path d="M28.19 40.31c6.627 0 12-5.374 12-12 0-6.628-5.373-12-12-12-6.628 0-12 5.372-12 12 0 6.626 5.372 12 12 12zm30.72-19.825c4.686 4.687 12.284 4.687 16.97 0 4.686-4.686 4.686-12.284 0-16.97-4.686-4.687-12.284-4.687-16.97 0-4.687 4.686-4.687 12.284 0 16.97zm35.74 7.705c0 6.627 5.37 12 12 12 6.626 0 12-5.373 12-12 0-6.628-5.374-12-12-12-6.63 0-12 5.372-12 12zm19.822 30.72c-4.686 4.686-4.686 12.284 0 16.97 4.687 4.686 12.285 4.686 16.97 0 4.687-4.686 4.687-12.284 0-16.97-4.685-4.687-12.283-4.687-16.97 0zm-7.704 35.74c-6.627 0-12 5.37-12 12 0 6.626 5.373 12 12 12s12-5.374 12-12c0-6.63-5.373-12-12-12zm-30.72 19.822c-4.686-4.686-12.284-4.686-16.97 0-4.686 4.687-4.686 12.285 0 16.97 4.686 4.687 12.284 4.687 16.97 0 4.687-4.685 4.687-12.283 0-16.97zm-35.74-7.704c0-6.627-5.372-12-12-12-6.626 0-12 5.373-12 12s5.374 12 12 12c6.628 0 12-5.373 12-12zm-19.823-30.72c4.687-4.686 4.687-12.284 0-16.97-4.686-4.686-12.284-4.686-16.97 0-4.687 4.686-4.687 12.284 0 16.97 4.686 4.687 12.284 4.687 16.97 0z">
                                <animateTransform attributeName="transform" type="rotate" from="0 67 67" to="360 67 67" dur="8s" repeatCount="indefinite" />
                            </path>
                        </svg>
                    </div>
                )}
                <div className="fixed bottom-6 ltr:right-6 rtl:left-6 z-50 space-y-4">
                    {showTopButton && !showChat && (
                        <button type="button" className="btn btn-outline-primary rounded-full p-2 animate-pulse bg-[#fafafa] dark:bg-[#060818] dark:hover:bg-primary" onClick={goToTop}>
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="1.5">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M8 7l4-4m0 0l4 4m-4-4v18" />
                            </svg>
                        </button>
                    )}
                    
                        {!showChat && <button type="button" className="btn btn-outline-primary animate-bounce rounded-full p-2  bg-[#fafafa]  " onClick={handlechat}>
                            <IconChatDot/>
                        </button>}
                        {showChat&&<div className=' md:absolute md:bottom-2 md:right-2 z-50'>
                   <div className={`flex gap-5 relative h-full   sm:h-[calc(100vh_-_150px)]  md:w-[400px] md:h-[500px] sm:min-h-0 ${isShowChatMenu ? 'min-h-[999px]' : ''}`}>
                    <div className="panel p-0 flex-1 border border-gray-400">
                    <div className="relative h-full">
                        <div className="h-px w-full border-b border-white-light dark:border-[#1b2e4b]"></div>

                        <PerfectScrollbar  className="relative  h-[calc(100vh_-_300px)] chat-conversation-box">
                            <div className="space-y-5 p-4 sm:pb-0 pb-[68px] sm:min-h-[300px] min-h-[400px]">
                                <div className="block m-6 mt-0">
                                    <h4 className="text-xs text-center border-b border-[#f4f4f4] dark:border-gray-800 relative">
                                        <span className="relative top-2 px-3 bg-white dark:bg-black">{'Today, ' + local}</span>
                                    </h4>
                                </div>

                                <>
                                    {msgs.map((msg: any, index: number) => (
                                        <div key={index}>
                                            <div className={`flex items-start gap-3  ${msg.userid === 2 ? '' : 'justify-end'}`}>
                                                <div className={`flex-none `}>
                                                    {/* <img src=" " className="rounded-full h-10 w-10 object-cover" alt="" />

                                                <img src=" " className="rounded-full h-10 w-10 object-cover" alt="" /> */}
                                                </div>
                                                <div className="space-y-2">
                                                    <div className="flex items-center gap-3">
                                                        <div
                                                            className={`dark:bg-gray-800 p-4 py-2 rounded-md bg-black/10 ${
                                                                msg.userid === 1 ? 'ltr:rounded-br-none rtl:rounded-bl-none !bg-primary text-white' : 'ltr:rounded-bl-none rtl:rounded-br-none'
                                                            }`}
                                                        >
                                                            {msg.message}
                                                        </div>
                                                        <div className={`${msg.userid === 1 ? 'hidden' : ''}`}>
                                                            <IconMoodSmile className="hover:text-primary" />
                                                        </div>
                                                    </div>
                                                    <div className={`text-xs text-white-dark ${msg.userid === 1 ? 'ltr:text-right rtl:text-left' : ''}`}>now</div>
                                                </div>
                                            </div>
                                        </div>
                                    ))}
                                </>
                            </div>
                        </PerfectScrollbar>
                        <div className="p-4 absolute bottom-0 left-0 w-full">
                            <div className="sm:flex w-full space-x-3 rtl:space-x-reverse items-center">
                                <div className="relative flex-1">
                                    <input
                                        className="form-input rounded-full border-0 bg-[#f4f4f4] px-12 focus:outline-none py-2"
                                        placeholder="Type a message"
                                        value={textMessage}
                                        onChange={(e: any) => setTextMessage(e.target.value)}
                                        onKeyUp={sendMessageHandle}
                                    />
                                    <button type="button" className="absolute ltr:left-4 rtl:right-4 top-1/2 -translate-y-1/2 hover:text-primary">
                                        <IconMoodSmile />
                                    </button>
                                    <button type="button" className="absolute ltr:right-4 rtl:left-4 top-1/2 -translate-y-1/2 hover:text-primary" onClick={() => sendMessage()}>
                                        <IconSend />
                                    </button>
                                </div>
                                <div className="items-center space-x-3 rtl:space-x-reverse sm:py-0 py-3 hidden sm:block">
                                    <button type="button" className="bg-[#f4f4f4] dark:bg-[#1b2e4b] hover:bg-primary-light rounded-md p-2 hover:text-primary">
                                        <IconMicrophoneOff />
                                    </button>
                                    <button type="button" className="bg-[#f4f4f4] dark:bg-[#1b2e4b] hover:bg-primary-light rounded-md p-2 hover:text-primary">
                                        <IconDownload />
                                    </button>
                                    <button type="button" className="bg-[#f4f4f4] dark:bg-[#1b2e4b] hover:bg-primary-light rounded-md p-2 hover:text-primary">
                                        <IconCamera />
                                    </button>
                                    <button type="button" className="bg-[#f4f4f4] dark:bg-[#1b2e4b] hover:bg-primary-light rounded-md p-2 hover:text-primary">
                                        <IconHorizontalDots className="opacity-70" />
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
                         </div>}
                  
                </div>

                {/* BEGIN APP SETTING LAUNCHER */}
                {/* <Setting /> */}
                {/* END APP SETTING LAUNCHER */}

                <div className={`${themeConfig.navbar} main-container text-black dark:text-white-dark min-h-screen`}>
                    {/* BEGIN SIDEBAR */}
                    <Sidebar />
                    {/* END SIDEBAR */}

                    <div className="main-content flex flex-col min-h-screen">
                        {/* BEGIN TOP NAVBAR */}
                        <Header />
                        {/* END TOP NAVBAR */}

                        {/* BEGIN CONTENT AREA */}
                        <Suspense>
                            <div onClick={()=>setShowChat(false)} className={`${themeConfig.animation} p-6 animate__animated`}>{children}</div>
                        </Suspense>
                        {/* END CONTENT AREA */}

                        {/* BEGIN FOOTER */}
                        <Footer />
                        {/* END FOOTER */}
                        <Portals />
                    </div>
                </div>
                
            </div>
            
        </App>
    );
};

export default DefaultLayout;
